import { prisma } from "../db/prisma.js";
import { getAvailableSellableForSaleAsOf } from "./pendingSaleReservations.js";
import { getCompanySettings } from "./mastersQueries.js";
import { resolveStockProductId } from "./stockIntakeGrouping.js";

const FALLBACK_TAX = {
  vatRate: 0.1925,
  salesActual: 0.02,
  salesSimplified: 0.05,
  salesNoTaxpayer: 0.1,
};
const QTY_EPS = 0.000001;

function parseRate(value: string | null | undefined): number {
  const n = Number.parseFloat(String(value ?? "").trim());
  if (!Number.isFinite(n)) return 0;
  return n > 1 ? n / 100 : n;
}

function qtyStr(n: number): string {
  const rounded = Math.round(n * 1_000_000) / 1_000_000;
  return String(rounded);
}

async function soldQtyForDoProduct(
  deliveryOrderNo: string,
  productId: number,
): Promise<number> {
  const lines = await prisma.sale_lines.findMany({
    where: {
      product_id: productId,
      sales: {
        delivery_order_no: deliveryOrderNo,
        status: { in: ["VALIDATED", "PENDING"] },
        cancelled_at: null,
      },
    },
    select: { qty_kg: true },
  });
  return lines.reduce(
    (sum, line) => sum + (Number.parseFloat(line.qty_kg) || 0),
    0,
  );
}

export async function getTaxRatesAsOf(asOfDate: string) {
  const asOf = String(asOfDate ?? "").trim().slice(0, 10);
  const rows = await prisma.tax_rate_schedules.findMany({
    where: {
      is_active: true,
      ...(asOf ? { effective_from: { lte: asOf } } : {}),
    },
    orderBy: { effective_from: "desc" },
  });
  const pick = (kind: string) =>
    rows.find((r) => r.rate_kind === kind)?.rate ?? null;
  return {
    vatRate: parseRate(pick("VAT")) || FALLBACK_TAX.vatRate,
    salesActual: parseRate(pick("SALES_ACTUAL")) || FALLBACK_TAX.salesActual,
    salesSimplified:
      parseRate(pick("SALES_SIMPLIFIED")) || FALLBACK_TAX.salesSimplified,
    salesNoTaxpayer:
      parseRate(pick("SALES_NO_TAXPAYER")) || FALLBACK_TAX.salesNoTaxpayer,
  };
}

type SaleDisposition =
  | "NORMAL"
  | "RATION"
  | "PUBLIC_RELATION"
  | "RETAIL"
  | string
  | null
  | undefined;

function isLooseLpoProduct(product: {
  product_code: string | null;
  product_name: string;
  is_bottled: boolean;
}): boolean {
  if (product.is_bottled) return false;
  if ((product.product_code ?? "").trim().toUpperCase() === "LPO") return true;
  return product.product_name.trim().toLowerCase() === "loose palm oil";
}

async function findActiveCustomerTypeIdByNeedles(
  needles: string[],
): Promise<string | null> {
  const rows = await prisma.customer_type_definitions.findMany({
    where: { is_active: true },
    orderBy: { sort_order: "asc" },
  });
  const hit = rows.find((row) => {
    const text = `${row.code} ${row.name}`.toUpperCase();
    return needles.some((needle) => text.includes(needle));
  });
  return hit?.id ?? null;
}

/** Staff/Worker (CDC workers) type — used for Ration disposition pricing. */
async function getStaffWorkerCustomerTypeId(): Promise<string | null> {
  return findActiveCustomerTypeIdByNeedles(["STAFF", "WORKER", "RATION"]);
}

/** Retail type — used for Public relation / Retail disposition pricing. */
async function getRetailCustomerTypeId(): Promise<string | null> {
  return findActiveCustomerTypeIdByNeedles(["RETAIL"]);
}

async function getCustomerTypeLabel(customerTypeId: string): Promise<string> {
  const row = await prisma.customer_type_definitions.findUnique({
    where: { id: customerTypeId },
    select: { name: true, code: true },
  });
  return row?.name ?? row?.code ?? customerTypeId;
}

/**
 * Electron parity: disposition + customer type select the schedule.
 * Loose LPO requires a typed schedule; bottled / other products use direct (null type).
 */
export async function previewUnitPrice(payload: {
  productId?: number;
  asOfDate?: string;
  customerId?: number | null;
  saleDisposition?: SaleDisposition;
}) {
  const productId = Number(payload.productId);
  const asOf = String(payload.asOfDate ?? "").trim().slice(0, 10);
  if (!Number.isFinite(productId) || productId <= 0) {
    return { ok: false as const, error: "Product is required." };
  }
  if (!/^\d{4}-\d{2}-\d{2}$/.test(asOf)) {
    return { ok: false as const, error: "Transaction date must be YYYY-MM-DD." };
  }

  const disposition = String(payload.saleDisposition ?? "NORMAL").toUpperCase();
  let customerTypeId: string | null = null;

  if (payload.customerId != null && Number.isFinite(Number(payload.customerId))) {
    const customer = await prisma.customers.findUnique({
      where: { id: Number(payload.customerId) },
      select: { id: true, customer_type_id: true },
    });
    if (!customer) {
      return { ok: false as const, error: "Customer not found." };
    }
    customerTypeId =
      disposition === "RETAIL"
        ? await getRetailCustomerTypeId()
        : (customer.customer_type_id ?? null);
  } else if (disposition === "RATION") {
    customerTypeId = await getStaffWorkerCustomerTypeId();
  } else if (disposition === "PUBLIC_RELATION" || disposition === "RETAIL") {
    customerTypeId = await getRetailCustomerTypeId();
  } else {
    customerTypeId = null;
  }

  const product = await prisma.products.findUnique({
    where: { product_id: productId },
    include: {
      product_cats: { select: { is_bottled: true } },
    },
  });
  if (!product) {
    return { ok: false as const, error: `Product ${productId} was not found.` };
  }

  const isBottled = product.product_cats?.is_bottled === true;
  const isLooseLpo = isLooseLpoProduct({
    product_code: product.product_code,
    product_name: product.product_name,
    is_bottled: isBottled,
  });

  if (isLooseLpo && !isBottled && !customerTypeId) {
    return {
      ok: false as const,
      error: `Select a registered customer to resolve the price for "${product.product_name}".`,
    };
  }

  const schedules = await prisma.product_unit_price_schedules.findMany({
    where: {
      product_id: productId,
      effective_from: { lte: asOf },
      ...(isBottled || !isLooseLpo
        ? { customer_type_id: null }
        : { customer_type_id: customerTypeId }),
    },
    orderBy: { effective_from: "desc" },
    take: 1,
  });
  const hit = schedules[0];
  if (!hit) {
    if (isBottled || !isLooseLpo) {
      return {
        ok: false as const,
        error: `No unit price scheduled for "${product.product_name}" on or before ${asOf}. Add a price in Product pricing (setup).`,
      };
    }
    const typeLabel = customerTypeId
      ? await getCustomerTypeLabel(customerTypeId)
      : "customer type";
    return {
      ok: false as const,
      error: `No unit price scheduled for "${product.product_name}" (${typeLabel}) on or before ${asOf}. Add a price in Product pricing (setup).`,
    };
  }

  return { ok: true as const, unitPriceExTax: hit.unit_price_ex_tax };
}

/**
 * Active sales-point storage locations with SELLABLE qty > 0 for a product.
 * When intake grouping is on, member grades resolve to their pool product so
 * locations like Drum show pooled stock (same as Electron).
 */
export async function listStorageLocationsWithBalance(payload: {
  salesPointId?: number;
  productId?: number;
  asOfDate?: string | null;
}): Promise<Array<{ id: number; name: string; qty: number }>> {
  const salesPointId = Number(payload.salesPointId);
  const productId = Number(payload.productId);
  if (!Number.isFinite(salesPointId) || !Number.isFinite(productId)) return [];

  const stockProductId = await resolveStockProductId(prisma, productId);
  const [product, company] = await Promise.all([
    prisma.products.findUnique({
      where: { product_id: stockProductId },
      include: {
        product_cats: { select: { is_bottled: true } },
      },
    }),
    prisma.company_settings.findFirst({
      where: { id: "default" },
      select: { loose_palm_oil_require_sales_tank: true },
    }),
  ]);

  if (!product) return [];
  if (product.omits_storage_location) return [];

  const requireSalesTank =
    isLooseLpoProduct({
      product_code: product.product_code,
      product_name: product.product_name,
      is_bottled: Boolean(product.product_cats?.is_bottled),
    }) && Boolean(company?.loose_palm_oil_require_sales_tank ?? true);

  const locations = await prisma.storage_locations.findMany({
    where: {
      sales_point_id: salesPointId,
      is_active: true,
      ...(requireSalesTank ? { is_sales_tank: true } : {}),
    },
    include: { locations: { select: { location_name: true } } },
    orderBy: { id: "asc" },
  });

  const asOf =
    String(payload.asOfDate ?? "").trim().slice(0, 10) ||
    new Date().toISOString().slice(0, 10);
  const out: Array<{ id: number; name: string; qty: number }> = [];
  for (const loc of locations) {
    const qty = await getAvailableSellableForSaleAsOf(
      prisma,
      salesPointId,
      stockProductId,
      loc.id,
      asOf,
    );
    if (qty > QTY_EPS) {
      out.push({
        id: loc.id,
        name: loc.locations?.location_name ?? `Location #${loc.id}`,
        qty: Math.round(qty * 1_000_000) / 1_000_000,
      });
    }
  }

  out.sort((a, b) => a.name.localeCompare(b.name));
  return out;
}

export async function listAvailableDeliveryOrders(payload: {
  salesPointId?: number;
  customerId?: number;
}) {
  const salesPointId = Number(payload.salesPointId);
  const customerId = Number(payload.customerId);
  if (!Number.isFinite(salesPointId) || !Number.isFinite(customerId)) return [];

  const orders = await prisma.delivery_orders.findMany({
    where: {
      sales_point_id: salesPointId,
      customer_id: customerId,
      status: { in: ["VALIDATED", "PARTIALLY_FULFILLED"] },
      cancelled_at: null,
      destination_pending: false,
    },
    include: {
      delivery_order_details: true,
    },
    orderBy: { date_issued: "desc" },
    take: 200,
  });

  const customer = await prisma.customers.findUnique({
    where: { id: customerId },
    select: { name: true },
  });
  const productIds = [
    ...new Set(
      orders.flatMap((o) => o.delivery_order_details.map((d) => d.product_id)),
    ),
  ];
  const products = await prisma.products.findMany({
    where: { product_id: { in: productIds } },
    select: { product_id: true, product_name: true },
  });
  const productName = new Map(
    products.map((p) => [p.product_id, p.product_name]),
  );

  const rows: Array<Record<string, unknown>> = [];
  for (const order of orders) {
    for (const detail of order.delivery_order_details) {
      const orderQty = Number(detail.order_qty) || 0;
      const sold = await soldQtyForDoProduct(
        order.delivery_order_no,
        detail.product_id,
      );
      const balance = Math.max(0, orderQty - sold);
      if (balance < 0.000001) continue;
      rows.push({
        deliveryOrderNo: order.delivery_order_no,
        customerName: customer?.name ?? "",
        dateIssued: order.date_issued,
        productId: detail.product_id,
        productName: productName.get(detail.product_id) ?? "",
        balanceKg: qtyStr(balance),
        isCarryForward: order.source_kind === "CARRY_FORWARD",
        sourceDocumentNo: order.order_ref,
      });
    }
  }
  return rows;
}

export async function lookupDeliveryOrder(payload: {
  deliveryOrderNo?: string;
  salesPointId?: number;
  customerId?: number;
}) {
  const deliveryOrderNo = String(payload.deliveryOrderNo ?? "").trim();
  const salesPointId = Number(payload.salesPointId);
  const customerId = Number(payload.customerId);
  if (!deliveryOrderNo || !Number.isFinite(salesPointId)) return null;

  const order = await prisma.delivery_orders.findFirst({
    where: {
      delivery_order_no: deliveryOrderNo,
      sales_point_id: salesPointId,
    },
    include: {
      delivery_order_details: true,
      delivery_order_payment_details: true,
    },
  });
  if (!order || order.destination_pending) return null;
  if (order.status !== "VALIDATED" && order.status !== "PARTIALLY_FULFILLED") {
    return null;
  }

  const customer =
    order.customer_id != null
      ? await prisma.customers.findUnique({
          where: { id: order.customer_id },
          select: { id: true, name: true },
        })
      : null;

  const productIds = order.delivery_order_details.map((d) => d.product_id);
  const products = await prisma.products.findMany({
    where: { product_id: { in: productIds } },
    select: { product_id: true, product_name: true },
  });
  const productName = new Map(
    products.map((p) => [p.product_id, p.product_name]),
  );

  const perProduct = [];
  for (const d of order.delivery_order_details) {
    const orderQty = Number(d.order_qty) || 0;
    const soldQty = await soldQtyForDoProduct(
      order.delivery_order_no,
      d.product_id,
    );
    const balanceQty = Math.max(0, orderQty - soldQty);
    perProduct.push({
      productId: d.product_id,
      productName: productName.get(d.product_id) ?? "",
      orderQty: qtyStr(orderQty),
      soldQty: qtyStr(soldQty),
      balanceQty: qtyStr(balanceQty),
      unitPrice: d.unit_price ?? "0",
    });
  }

  const balanceKg = qtyStr(
    perProduct.reduce((sum, p) => sum + (Number.parseFloat(p.balanceQty) || 0), 0),
  );

  const paymentMethods = await prisma.payment_method_definitions.findMany();
  const methodById = new Map(paymentMethods.map((m) => [m.id, m]));

  return {
    deliveryOrderNo: order.delivery_order_no,
    dateIssued: order.date_issued,
    customerId: order.customer_id ?? 0,
    customerName: customer?.name ?? "",
    customerMatches:
      Number.isFinite(customerId) && order.customer_id === customerId,
    balanceKg,
    isCarryForward: order.source_kind === "CARRY_FORWARD",
    perProduct,
    payments: order.delivery_order_payment_details.map((p) => ({
      paymentMethodId: p.payment_method_id,
      kind: methodById.get(p.payment_method_id)?.kind ?? "CASH",
      chequeNo: p.cheque_no,
      bank: p.bank,
      traiteNo: null,
      traiteIssuedOn: null,
      traiteMaturityOn: null,
    })),
  };
}

export async function loadSalePrintById(saleId: string) {
  const id = String(saleId ?? "").trim();
  if (!id) return null;
  const sale = await prisma.sales.findUnique({
    where: { id },
    include: {
      sale_lines: { orderBy: { id: "asc" } },
      sale_applied_taxes: true,
      payments: true,
      sales_points: { select: { name: true } },
    },
  });
  if (!sale) return null;

  const [company, customer, user, products, paymentMethods] = await Promise.all([
    getCompanySettings(),
    sale.customer_id != null
      ? prisma.customers.findUnique({ where: { id: sale.customer_id } })
      : Promise.resolve(null),
    prisma.users.findUnique({
      where: { id: sale.created_by_user_id },
      select: { name: true },
    }),
    prisma.products.findMany({
      where: {
        product_id: { in: sale.sale_lines.map((l) => l.product_id) },
      },
      include: { product_cats: { select: { product_cat: true } } },
    }),
    prisma.payment_method_definitions.findMany(),
  ]);

  const productById = new Map(products.map((p) => [p.product_id, p]));
  const methodName = new Map(paymentMethods.map((m) => [m.id, m.name]));

  let appliedTaxes = sale.sale_applied_taxes.map((t) => ({
    label: t.label_snapshot,
    ratePercent: String((parseRate(t.rate_snapshot) * 100).toFixed(2)),
    amount: t.amount,
  }));

  // Older thin-client invoices may have tax folded into gross without rows in
  // sale_applied_taxes. Reconstruct so print matches the invoice modal.
  if (appliedTaxes.length === 0) {
    const net = Number.parseFloat(String(sale.net_amount ?? "0")) || 0;
    const vat = Number.parseFloat(String(sale.vat_amount ?? "0")) || 0;
    const gross = Number.parseFloat(String(sale.gross_amount ?? "0")) || 0;
    const salesTax = Math.round(gross - net - vat);
    const vatRate = parseRate(sale.vat_rate_snapshot);
    if (vat > 0.000001) {
      appliedTaxes.push({
        label: "VAT",
        ratePercent: String((vatRate * 100).toFixed(2)),
        amount: String(Math.round(vat)),
      });
    }
    if (salesTax > 0.000001) {
      const salesTaxRate = net > 0 ? salesTax / net : 0;
      appliedTaxes.push({
        label: "Sales tax",
        ratePercent: String((salesTaxRate * 100).toFixed(2)),
        amount: String(salesTax),
      });
    }
  }

  return {
    companyName: company?.companyName ?? "MPOS",
    department: company?.department ?? null,
    serviceName: sale.commercial_service_name_snapshot,
    companyPhone: sale.issuer_phone_snapshot,
    companyAddress: sale.issuer_address_snapshot,
    logoUrl: company?.logoUrl ?? null,
    signatoryName: "NYAKE VICTORINE Epse MBUA",
    signatoryTitle: "Manager, Palm Oil Sales",
    sale: {
      invoiceNo: sale.invoice_no,
      status: sale.status,
      soldAtIso: sale.sold_at.toISOString(),
      vehicleNumber: sale.vehicle_number ?? "",
      dateIssuedIso: sale.date_issued,
      deliveryOrderNo: sale.delivery_order_no,
      referenceNumber: sale.reference_number,
      customerName: sale.customer_name_snapshot || customer?.name || "",
      customerAddress: customer?.address ?? null,
      customerPhone: customer?.phone ?? null,
      taxpayerId: customer?.taxpayer_id ?? null,
      salespersonName: user?.name ?? null,
      salesPointName: sale.sales_points?.name ?? null,
      saleProductMode: sale.sale_product_mode,
      saleDisposition: sale.sale_disposition,
      netAmount: sale.net_amount,
      vatAmount: sale.vat_amount,
      grossAmount: sale.gross_amount,
      appliedTaxes,
      lines: sale.sale_lines.map((line, index) => {
        const product = productById.get(line.product_id);
        return {
          lineNo: index + 1,
          productCode: product?.product_code ?? null,
          productName: product?.product_name ?? "",
          productCat: product?.product_cats?.product_cat ?? "",
          qty: line.qty_kg,
          unitLabel: product?.uom ?? "Kg",
          unitPrice: line.unit_price_per_kg,
          lineNet: line.line_net,
        };
      }),
      payments: sale.payments.map((p) => ({
        methodName: methodName.get(p.payment_method_id) ?? p.payment_method_id,
        amount: p.amount,
        paymentDate: p.paid_at.toISOString().slice(0, 10),
      })),
    },
  };
}
